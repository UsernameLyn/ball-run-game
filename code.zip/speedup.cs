using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {   /*
        ref float speeds = GameObject.Find("player").GetComponent<player>().updatespeed();
        // float x = Input.GetAxis("Horizontal");
        //player.transform.Translate(x * 8 * Time.deltaTime, 0, 200 * Time.deltaTime);
        float speed = 20;
        speeds = ref speed;
        */
    }
}
