using System;
using Microsoft.Win32;
using System.Threading;
using System.Collections;
using System.Collections.Generic;
using System.IO.Ports;

using UnityEngine;
using UnityEngine.SceneManagement;

public class player : MonoBehaviour
{
    public float speed=10;
    public float turnspeed = 4;
    public float jumpspeed = 10;
    public float jumpheight = 6;
    private float jumptarget =0;
    private int direction;
    //ref  public float speeds =  speed;
    serialport Serialport;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {   
         direction = GameObject.Find("player").GetComponent<serialport>().PrintData();  //get the direction from port
        if (direction != 0)
        {
            Debug.Log("updating by port");
            Debug.Log(direction);
        }
        
        #region  update speed 
        /*

          ref float speedupdate()
        {
            return speeds;
        } 

        */
        #endregion


        #region  left and right
        if (direction == 1)
        {              
            transform.Translate(-1* turnspeed * Time.deltaTime, 0, speed * Time.deltaTime);
            Debug.Log("turn left");
        }
        if (direction == 2)
        {
            transform.Translate(1 * turnspeed * Time.deltaTime, 0, speed * Time.deltaTime);
            Debug.Log("turn right");
        }

        #endregion
        //reboot
        if (Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(0);
            direction = 0;
            Time.timeScale = 1;
            return;
        }



        #region  jump
        jump();
        #endregion



        float x = Input.GetAxis("Horizontal");
        transform.Translate(x*turnspeed*Time.deltaTime, 0 ,speed *Time.deltaTime);


        //rotate
        var c = Camera.main.transform;
        Quaternion cur = c.rotation;
        Quaternion target = cur * Quaternion.Euler(0, 0, x * 0.5f);
        Camera.main.transform.rotation = Quaternion.Slerp(cur, target, 0.1f);


        //falldown
        falldown();


    }

    void jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //Debug.Log("nmsl");
            jumptarget = jumpheight;
        }
        if (direction == 3)
        {
            jumptarget = jumpheight;
            direction = 0;  
            //Debug.Log("jump")
        }
        //Debug.Log(jumptarget);
        float x = Input.GetAxis("Horizontal");
        Vector3 distance = speed * Time.deltaTime * new Vector3(x, 0, 1);
        if (jumptarget > 0)
        {
            //Debug.Log(Vector3.up);
            transform.Translate(Vector3.up * jumpspeed * Time.deltaTime);
            //transform.Translate(x * turnspeed * Time.deltaTime,4* jumpspeed * Time.deltaTime,speed * Time.deltaTime);
            if (transform.position.y >= jumptarget)
            {
                Debug.Log("jump");
                jumptarget = 0;
            }
        }
        else if (transform.position.y > 1)
        {
            transform.Translate(Vector3.down * jumpspeed * Time.deltaTime);
            if (transform.position.y < 1)
            {
                Vector3 newPos = transform.position;
                newPos.y = 1;
                transform.position = newPos;
            }
        }
    }


    void falldown()
    {
        if (transform.position.x < -7.5 || transform.position.x > 7.5)
        {
            transform.Translate(0, -10 * Time.deltaTime, 0);
            if (transform.position.y < -10)     Time.timeScale = 0;
        }
    }
}
