using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Microsoft.Win32;

using System.IO.Ports;
using UnityEngine;



public class serialport : MonoBehaviour
{

    //private int direction=0;
    #region   
    
    public string portName = "COM5";
    public int baudRate = 9600;
    public Parity parity = Parity.None; //jiaoyan
    public StopBits stopbits = StopBits.One;
    public int databits = 8;
    SerialPort sp = null;
    Thread dataReceiveThread;
    //float timer = 0;        //unknown thing
    //string message = "";
    public List<byte> listReceive = new List<byte>();
    string str;
    private int ss = 0;
    //void DataReceiveFunction() { }
    #endregion

    //SerialPort serialPort;
    // Start is called before the first frame update
    void Start()
    {
        //serial port configration
        //serialPort = new SerialPort("com3",9600,Parity.None,8,StopBits.One); 
        //��port name; baute rate;  
        //serialPort.Open();
        OpenPort();
        dataReceiveThread = new Thread(new ThreadStart(DataReceiveFunction));
        dataReceiveThread.Start();

    }

    // Update is called once per frame
    void Update()
    {/*
        if (serialPort.BytesToRead > 0)
        {
            string data = serialPort.ReadLine();
            Debug.Log(data);
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            serialPort.WriteLine("hello world");
        }*/
        PrintData();
    }

    #region   get port name
    private string[] ScanPorts_Regedit()
    {
        RegistryKey Keycom = Registry.LocalMachine.OpenSubKey("Hardware\\DeviceMap\\SerialComm");
        string[] SubKeys = Keycom.GetValueNames();
        string[] portlist = new string[SubKeys.Length];
        for (int i = 0; i < SubKeys.Length; i++)
        {
            portlist[i] = (string)Keycom.GetValue(SubKeys[i]);
        }
        return portlist;
    }

    #endregion

    #region �������ڲ���
    public void OpenPort()
    {      

        sp=new SerialPort(portName, baudRate,parity,databits,stopbits);
        if(!sp.IsOpen)
        {
            string[]  portarray = ScanPorts_Regedit();
            portName = portarray[0];
            sp = new SerialPort(portName, baudRate, parity, databits, stopbits);
            Debug.Log(portName);
        }
        sp.ReadTimeout = 400;
        try
        {
            sp.Open();
        }
        catch(System.Exception ex) {
            Debug.Log(ex.Message);
        }
        if( sp.IsOpen )
        {
            Debug.Log("port is opened");
        }
    }
    #endregion

    #region  �رմ���
    void OnApplicationQuit()
    {
        try
        {
            sp.Close();
            dataReceiveThread.Abort();
        }
        catch (System.Exception ex)
        {
            Debug.Log(ex.Message);
        }
        Debug.Log("port is closed");
    }
    #endregion

    //print data
    public int   PrintData()
    {
        //Debug.Log("direction printing");
        //Debug.Log(ss);
        if (ss != 0) Debug.Log(ss);
        int x = 0;
        if(ss == 1)  x = 1;
        else if(ss == 2) x = 2;  
        else if(ss == 3) x = 3;
        else if(ss == 4) x = 4;
        return x;
    }

    
    private void DataTransfrom(int a,ref int ss)
    {
        ss = a;
    }
    /*
   private ref int DataTransfrom(int a,ref int ss)
   {
       ss = a;
       return &ss;
   }
   */
    //data receive
   void DataReceiveFunction()
    {
        #region  receive data bit by bit
        int bytes = 0;
        while (true)
        {
            //Debug.Log("receiving");
            if (sp != null && sp.IsOpen)
            {
                try
                {
                    bytes = sp.BytesToRead;
                    //bytes = sp.Read(buffer, 0, buffer.Length);
                    //bytes = sp.Read(buffer, 0, 4);
                    //print(bytes);
                    if (bytes == 0)
                    {
                        continue;
                    }
                    else
                    {
                        byte[] buffer = new byte[bytes];
                        // Debug.Log("bytes!=0"+bytes);
                        #region   obsolete version
                        //int s=sp.Read(buffer,0,bytes);
                        int s = sp.ReadByte();
                        Debug.Log(s);
                        // Debug.Log(s);
                        //aDebug.Log("receiving...really");
                        //int s = 0;
                        //s = 0;
                        //byte H = buffer[1];
                        // byte L = buffer[0];
                        // s = (short)(s ^ H);
                        //s = (short)(s <<8);
                        //s = (short)(s ^ L);
                        //print("nmysl");
                        // ss_address= DataTransfrom(s, ref ss);
                        DataTransfrom(s, ref ss);
                       
                        //Debug.Log(ss);


                        #endregion

                        #region
                        /*
                        byte[] readbuffer =new byte[bytes+1];
                        str = ToString(readbuffer[0]);
                        Debug.Log(str);
                        */
                        #endregion
                    }
                    //Debug.Log(buffer[3]+"   "+ buffer[2] + "   "+buffer[1] + "   " + buffer[0]);
                }
                catch (System.Exception ex)
                {
                    //Debug.Log(ex.Message); 
                }
                Debug.Log(ss);
                //Thread.Sleep(50);               
            }
        }
        #endregion
        //if (ss != 0) Debug.Log(ss);
    }



    /*
    public int  DataReceiveFunction1()
    {
        #region  receive data bit by bit
        int bytes = 0;
        while (true)
        {
            //Debug.Log("receiving");
            if (sp != null && sp.IsOpen)
            {   
                try
                {
                    bytes = sp.BytesToRead;
                    //bytes = sp.Read(buffer, 0, buffer.Length);
                    //bytes = sp.Read(buffer, 0, 4);
                    //print(bytes);
                    if (bytes == 0)
                    {
                        continue;
                    }
                    else
                    {
                        byte[] buffer = new byte[bytes];
                       // Debug.Log("bytes!=0"+bytes);
                        #region   obsolete version
                        //int s=sp.Read(buffer,0,bytes);
                        int s = sp.ReadByte();
                        Debug.Log(s);
                        return s;
                        #endregion
                            */
    #region
    /*
    byte[] readbuffer =new byte[bytes+1];
    str = ToString(readbuffer[0]);
    Debug.Log(str);
    */
    #endregion
    /*
                    }
                    //Debug.Log(buffer[3]+"   "+ buffer[2] + "   "+buffer[1] + "   " + buffer[0]);
                }
                catch (System.Exception ex) { 
                    //Debug.Log(ex.Message); 
                }
                Debug.Log(ss);
                //Thread.Sleep(50);               
            }           
        }
        #endregion
   }
        */

    public void WriteData(string datastr)
    {
        if(sp.IsOpen) { 
            sp.Write(datastr);
        }
    } 
}



