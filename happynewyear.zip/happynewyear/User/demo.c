
#include "OLED.h"
#include "demo.h"
#include "atk_ms7620.h"
#include "Serial.h"
#include "delay.h"


void demo_run(void)
{
    uint8_t ret;
    atk_ms7620_gesture_t gesture;
    
    OLED_Init();
    ret = atk_ms7620_init();
    if (ret != 0)
    {
        //printf("ATK-MS7620 init failed!\r\n");
		OLED_ShowString(1,1,"init failed!");
        while (1)
        {
            
            Delay_ms(200);
        }
    }
    
   
    ret = atk_ms7620_mode_config(ATK_MS7620_MODE_GESTURE);
    if (ret != 0)
    {	
		OLED_ShowString(1,1,"config failed!");
        //printf("MS7620 config failed!\r\n");
        while (1)
        {
            
            Delay_ms(200);
        }
    }
    OLED_ShowString(1,1,"succedded");
    //printf("ATK-MS7620 config succedded!\r\n");
    
    while (1)
    {
        
        ret = atk_ms7620_get_gesture(&gesture);
        if (ret == ATK_MS7620_EOK)
        {
            switch (gesture)
            {
                case ATK_MS7620_GESTURE_UP:
                {	
					OLED_Clear();
					OLED_ShowString(1,1,"up");
					Serial_SendByte (1);
                    //printf("Gesture: Up\r\n");
                    break;
                }
                case ATK_MS7620_GESTURE_DOWN:
                {	
					OLED_Clear();
					OLED_ShowString(1,1,"down");
					Serial_SendByte (2);
                    //printf("Gesture: Down\r\n");
                    break;
                }
                case ATK_MS7620_GESTURE_LEFT:
                {
					OLED_Clear();
					OLED_ShowString(1,1,"left");
                    //printf("Gesture: Left\r\n");
                    break;
                }
                case ATK_MS7620_GESTURE_RIGHT:
                {
					OLED_Clear();
					OLED_ShowString(1,1,"right");					
                    //printf("Gesture: Right\r\n");
                    break;
                }
                case ATK_MS7620_GESTURE_FORWARD:
                {
					OLED_Clear();
					OLED_ShowString(1,1,"forward");					
                    //printf("Gesture: Forward\r\n");
                    break;
                }
                case ATK_MS7620_GESTURE_BACKWARD:
                {
					OLED_Clear();
					OLED_ShowString(1,1,"backword");					
                    //printf("Gesture: Backward\r\n");
                    break;
                }
                case ATK_MS7620_GESTURE_CLOCKWISE:
                {
					OLED_Clear();
					OLED_ShowString(1,1,"clockwise");					
                    //printf("Gesture: Clockwise\r\n");
                    break;
                }
                case ATK_MS7620_GESTURE_ANTICLOCKWISE:
                {
					OLED_Clear();
					OLED_ShowString(1,1,"antickws");					
                   // printf("Gesture: Anticlockwise\r\n");
                    break;
                }
                case ATK_MS7620_GESTURE_WAVE:
                {
					OLED_Clear();
					OLED_ShowString(1,1,"wave");					
                    //printf("Gesture: Wave\r\n");
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    }
}
