#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Serial.h"
#include "MyIIC.h"
#include "delay.h"
#include "demo.h"

uint8_t RxData;

int main(void)
{
	OLED_Init();
	//OLED_ShowString(1, 1, "RxData:");
	
	Serial_Init();
	My_IIC_Init();
	My_IIC_Start();
	//Serial_SendByte(1);
	//My_IIC_SendByte(0x73);
	//uint8_t ack= My_IIC_ReceiveAck();
	//My_IIC_Stop();
	//OLED_ShowNum(1,1,ack,3);
	/*
	while (1)
	{
		if (Serial_GetRxFlag() == 1)
		{
			RxData = Serial_GetRxData();
			Serial_SendByte(RxData);
			OLED_ShowHexNum(1, 8, RxData, 2);
		}
	}
	*/
	My_IIC_Start();
	demo_run();
	while(1){
		
	}
}
