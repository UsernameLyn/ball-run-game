 
#ifndef   _MyIIC_H
	#define _MyIIC_H
	
	void MyI2C_W_SCL(uint8_t BitValue);
	void MyI2C_W_SDA(uint8_t BitValue);
	uint8_t My_IIC_R_SDA(void);
	void My_IIC_Init(void);
	void My_IIC_Start(void);
	void My_IIC_Stop(void);
	void My_IIC_SendByte(uint8_t Byte);
	void My_IIC_SendAck(uint8_t AckByte)	;
	uint8_t My_IIC_ReceiveByte(void);
	uint8_t My_IIC_ReceiveAck(void);
	
	
#endif

